<html>
<title>Joomla Private Scanner</title>
<body>
<center>
<style>
#text3
{
background: #333;
color: #ccc;
width: 1000px;
padding: 6px 15px 6px 35px;
transition: 500ms all ease;
border: 1px solid #333;
}
#text3:hover
{

box-shadow: 12px 13px 0px rgba(204, 211, 51, 0.38),
-11px -14px 0px rgba(241, 96, 0, 0.28),
18px -24px 0px rgba(0, 0, 0, 0.34),
33px -6px 0px rgba(39, 74, 214, 0.28);
}
</style>
<p id="text3" type="text"
<?php

$retval= "test";
$target = $_POST['target'];
$output = array();
exec("python scan.py $target ", $output,$retval);
foreach($output as $v => $l){

echo  $l."<br/>";	

}

?>
 </p>"
</center>