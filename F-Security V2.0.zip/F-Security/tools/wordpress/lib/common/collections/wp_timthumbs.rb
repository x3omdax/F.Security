# encoding: UTF-8

require 'common/collections/wp_timthumbs/detectable'

class WpTimthumbs < WpItems
  extend WpTimthumbs::Detectable

end
