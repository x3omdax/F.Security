<?php
set_time_limit(0);
error_reporting(0);
/*
[*]------------------------------------------------------------------------------[*]
[+] Tool                 : PHP Port Scanning        
[+] Coded By             : Wesleti Fedy
[+] Facebook             : https://www.facebook.com/ceh.tn
[!] Hint: if you want to Scanning One Port / Use: Port Start: 80 Port Ended: 80 ...
[*]------------------------------------------------------------------------------[*]
*/
echo '
<title>Port Scanning</title>
<center>
<body bgcolor="black">
<form method ="POST">
<p>
<img border="0" src="http://census2012.sourceforge.net/images/clientmap_16to9_3200x1800.png" width="589" height="351"></p>
<p><b>
<font color="white">&nbsp;Target:</font> </b>
<input type="text" name="site" size="23" value="domine.com"/>
<b>
<font color="white">Port Start:</font> </b>
<input type="text" name="port1" size="20" /> <b>
<font color="white">Port Ended:</font> </b> <input type="text" name="port2" size="20" />
</p>
<p>&nbsp;<font size="5" color="white"><b>Scanner: </b></font> <input type="submit" name="scanner" size="20" value="Start!"/>
</p>
<p><font color="white" size="5"><b>Coded By Wesleti Fedy</b></font></p>
</form>
</body>
<font color="white"><b>Hint: if you want to Scanning One Port Use: Port Start: 80 Port Ended: 80 ...
</b></font>
</center>
';
$url = strip_tags(trim($_POST['site']));
$port_start = strip_tags(trim($_POST['port1']));
$port_ended = strip_tags(trim($_POST['port2']));
$s0w = 1;
 
if (empty($url) or empty($port_start)or empty($port_ended)) {
               
                die('<center><b><font color="white" size=3 >[ ! ] Do not leave the fields blank .. [ ! ]</font></b></center>');
}
 
        if (isset($_POST{'scanner'})) {
       
                for ($i = $port_start; $i <= $port_ended; $i++) {
       
$open = fsockopen($url, $i, $egy, $pow, $s0w);
 
        if (getservbyport($i, 'tcp') == '') $low = "Unknown";
 
                else $low = getservbyport($i, 'tcp');
 
        if ($open){
               
                echo "<br />"; 
               
                echo "<font color=#FFFF00 size=6><b>Target:" . "\n". $url ."\n" . "ip:". gethostbyname($url) ."<br /></font>";
               
                echo "<br />";
               
                echo "<font color=#00FF00 size=4>Port {$i} on {$url} is Open \n" ."<br /></font>";     
               
        fclose($open);
       
        }else{
    echo "<font color=red size=4>Port {$i} on {$url} is inactive \n" ."<br /></font>";
        }
        }
        }
?>