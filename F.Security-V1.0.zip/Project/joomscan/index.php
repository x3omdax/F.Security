<html>
<title>Joomla Private Scanner</title>
<body>
<style>
html {
  height: 100%;
  
  background-color: #222;
  
  background-image:
    linear-gradient(
      155deg,
      transparent 13%,
      hsla(200,40%,60%,1) 15%,
      transparent 0
      ),
    linear-gradient(
      90deg,
      transparent 49%,
      hsla(200,40%,60%,1) 49%,
      hsla(200,40%,60%,1) 50%,
      transparent 0
      ),
    linear-gradient(
      65deg,
      transparent 31%,
      hsla(200,40%,60%,1) 33%,
      transparent 0
      ),
    linear-gradient(
      45deg,
      transparent 47%,
      hsla(200,40%,60%,1) 49%,
      transparent 0
      ),
    linear-gradient(
      25deg,
      transparent 32%,
      hsla(200,40%,60%,1) 34%,
      transparent 0
      ),
    linear-gradient(
      -25deg,
      transparent 60%,
      hsla(200,40%,60%,1) 62%,
      transparent 0
      ),
    linear-gradient(
      -65deg,
      transparent 31%,
      hsla(200,40%,60%,1) 33%,
      transparent 0
      ),
    linear-gradient(
      180deg,
      transparent 53%,
      hsla(200,40%,60%,1) 55%,
      transparent 0
      ),
    linear-gradient(
      -25deg,
      transparent 32%,
      hsla(200,40%,60%,1) 34%,
      transparent 0
      ),
    linear-gradient(
      -65deg,
      transparent 65%,
      hsla(200,40%,60%,1) 67%,
      transparent 0
      ),
    linear-gradient(
      -45deg,
      transparent 47%,
      hsla(200,40%,60%,1) 49%,
      transparent 0
      );
  
  background-size: 
    80px 100px, 
    100px 100px, 
    75px 100px, 
    75px 100px, 
    80px 100px, 
    80px 100px, 
    80px 100px, 
    80px 100px, 
    80px 100px, 
    75px 100px, 
    80px 100px;
  
  background-position: 50% 50%;
  background-repeat: no-repeat;
  
  animation: sloppy 2s linear infinite alternate;
  }

@keyframes sloppy {
  0% {
    background-size:  
      0 100px, 
      100px 0, 
      0 100px, 
      0 100px, 
      0 100px, 
      0 100px, 
      0 100px, 
      0 100px, 
      0 100px, 
      0 100px, 
      0 100px;
    }
  10% {
    background-size: 
      0 100px, 
      100px 100px, 
      0 100px, 
      0 100px, 
      0 100px, 
      0 100px, 
      0 100px, 
      0 100px, 
      0 100px, 
      0 100px, 
      0 100px; 
    }
  20% {
    background-size: 
      0 100px, 
      100px 100px, 
      0 100px, 
      0 100px, 
      0 100px, 
      80px 100px, 
      0 100px, 
      0 100px, 
      0 100px, 
      0 100px, 
      0 100px; 
    }
  30% {
    background-size: 
      80px 100px, 
      100px 100px, 
      0 100px, 
      0 100px, 
      0 100px, 
      80px 100px, 
      0 100px, 
      0 100px, 
      0 100px, 
      0 100px, 
      0 100px; 
    }
  40% {
    background-size: 
      80px 100px, 
      100px 100px, 
      0 100px, 
      75px 100px, 
      0 100px, 
      80px 100px, 
      0 100px, 
      0 100px, 
      0 100px, 
      0 100px, 
      0 100px; 
    }
  50% {
    background-size: 
      80px 100px, 
      100px 100px, 
      0 100px, 
      75px 100px, 
      0 100px, 
      0 100px, 
      80px 100px, 
      80px 100px, 
      0 100px, 
      0 100px, 
      0 100px; 
    }
  60% {
    background-size: 
      80px 100px, 
      100px 100px, 
      75px 100px, 
      75px 100px, 
      0 100px, 
      0 100px, 
      80px 100px, 
      80px 100px, 
      0 100px, 
      0 100px, 
      0 100px; 
    }
  70% {
    background-size: 
      80px 100px, 
      100px 100px, 
      75px 100px, 
      75px 100px, 
      80px 100px, 
      0 100px, 
      80px 100px, 
      80px 100px, 
      0 100px, 
      0 100px, 
      80px 100px; 
    }
  80% {
    background-size: 
      80px 100px, 
      100px 100px, 
      75px 100px, 
      75px 100px, 
      80px 100px, 
      80px 100px, 
      80px 100px, 
      80px 100px, 
      0 100px, 
      75px 100px, 
      80px 100px; 
    }
  90% {
    background-size: 
      80px 100px, 
      100px 100px, 
      75px 100px, 
      75px 100px, 
      80px 100px, 
      80px 100px, 
      80px 100px, 
      80px 100px, 
      80px 100px, 
      75px 100px, 
      80px 100px; 
    }
  100% {
    background-size: 
      80px 100px, 
      100px 100px, 
      75px 100px, 
      75px 100px, 
      80px 100px, 
      80px 100px, 
      80px 100px, 
      80px 100px, 
      80px 100px, 
      75px 100px, 
      80px 100px;    
    }
  }
  </style>
<style> 
#text {
    background: #333;
    color: #ccc;
    width: 200px;
    padding: 6px 15px 6px 35px;
    border-radius: 20px;
    box-shadow: 0 1px 0 #ccc inset;
    transition: 500ms all ease;
    outline: 0;
}

#text3:hover {
    width: 270px;
}  
</style>

 <center>
<form  action="scan.php" method="post"><font color="white">
<br> <br> Target: </font><input id="text" type="text" name="target"><br>
<input  type="Submit" value="Scan">
</form>
</center>
</body>
</html>